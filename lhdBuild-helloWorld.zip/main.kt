fun main(args: Array<String>) {
  println("Hello, World!")
  println("Kaoutar says Hi ^_^")
  println("From Ouarzazate, Morocco!")
}